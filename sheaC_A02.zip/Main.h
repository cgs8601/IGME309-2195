/*----------------------------------------------
Programmer: Alberto Bobadilla (labigm@gmail.com)
Date: 2017/05
----------------------------------------------*/
#ifndef __MAIN_H_
#define __MAIN_H_
#include "AppClass.h"
#define _CRTDBG_MAP_ALLOC
#include <cstdlib>
#include <crtdbg.h>
void wrapper();

#endif //__MAIN_H_

/*
USAGE:
ARGUMENTS: ---
OUTPUT: ---
*/